public enum Rango {
    GENIN, CHUNIN, JONIN, AMBU, KAGE
}
