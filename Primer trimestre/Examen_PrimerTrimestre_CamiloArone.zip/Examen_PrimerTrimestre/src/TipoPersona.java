public enum TipoPersona {
    NINJA, SENSEI
}
